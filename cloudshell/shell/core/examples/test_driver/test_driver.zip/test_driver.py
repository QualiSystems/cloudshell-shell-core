from cloudshell.shell.core.context.context_utils import context_from_args
from test_bootstrap import TestBootstrap
import inject
import time


class TestDriver:
    def __init__(self):
        TestBootstrap().initialize()

    @context_from_args
    def initialize(self, context):
        """
        :type context: cloudshell.shell.core.driver_context.InitCommandContext
        """
        return 'Finished initializing'

    # Destroy the driver session, this function is called everytime a driver instance is destroyed
    # This is a good place to close any open sessions, finish writing to log files
    def cleanup(self):
        pass

    @context_from_args
    @inject.params(logger='logger')
    def simple_command(self, context, command, logger=None):
        # for i in range(0, int(command)):
        #     logger.info('Resource: ' + context.resource.name)
        #     time.sleep(1)
        # return logger.log_path
        return "Ok"
