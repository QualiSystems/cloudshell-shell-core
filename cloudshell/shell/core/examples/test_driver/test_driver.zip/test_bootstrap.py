from cloudshell.shell.core.driver_bootstrap import DriverBootstrap


class TestBootstrap(DriverBootstrap):
    def configuration(self, binder):
        # super(test_bootstrap, self).configuration(binder)
        pass
